1. Register as admin
   python manage.py makemigrations

   python manage.py makemigrate

   python manage.py createsuperuser

   username:sakshi
   password:123456

2. python manage.py runserver
   http://127.0.0.1:8000/
   
   open this url in browser

3. Login as admin 

4. Login as student      

   


 